$logFile = "C:\Scripts\logs\winget_updates_$(Get-Date -Format 'yyyy-MM-dd').log"
Start-Transcript -Path $logFile -Append

Function Get-WingetCmd {

    $WingetCmd = $null

    #Get WinGet Path
    try {
        #Get Admin Context Winget Location
        $WingetInfo = (Get-Item "$env:ProgramFiles\WindowsApps\Microsoft.DesktopAppInstaller_*_8wekyb3d8bbwe\winget.exe").VersionInfo | Sort-Object -Property FileVersionRaw
        #If multiple versions, pick most recent one
        $WingetCmd = $WingetInfo[-1].FileName
    }
    catch {
        #Get User context Winget Location
        if (Test-Path "$env:LocalAppData\Microsoft\WindowsApps\Microsoft.DesktopAppInstaller_8wekyb3d8bbwe\winget.exe") {
            $WingetCmd = "$env:LocalAppData\Microsoft\WindowsApps\Microsoft.DesktopAppInstaller_8wekyb3d8bbwe\winget.exe"
        }
    }

    return $WingetCmd
}

$winget = Get-WingetCmd

if (-not $winget) {
    Write-Error "Winget executable not found"
    Stop-Transcript
    exit 1
}

Write-Output "Starting winget updates at $(Get-Date)"

$packagesPath = "C:\Scripts\packages.txt"
if (Test-Path -Path $packagesPath) {
    $packages = Get-Content -Path $packagesPath | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    
    foreach ($package in $packages) {
        Write-Output "Updating package: $package"
        & $winget upgrade $package --accept-source-agreements --accept-package-agreements
    }
} else {
    Write-Error "Packages file not found at $packagesPath"
}

Write-Output "Completed winget updates at $(Get-Date)"
Stop-Transcript